﻿using System.Text;
using System.Net;
using System.IO;

namespace HourJournalIntegration
{
    public class HourJournal
    {
        public static string WebService()
        {
            AXCredentialsContract axCredentialsContract = AXConnector.GetAppConfiguration();

            string auth = OAuthHelper.GetAuthenticationToken();

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://usnconeboxax1aos.cloud.onebox.dynamics.com/api/services/DHRP_LMSServiceGroup/DHRP_LMSService/getCourseInformation");
            request.Headers.Add("Authorization", auth);
            request.ContentType = "application/json";
            request.Method = "POST";

            string jsonData = "";

            var bytes = Encoding.ASCII.GetBytes(jsonData);

            using (Stream newStream = request.GetRequestStream())
            {
                newStream.Write(bytes, 0, jsonData.Length);
                newStream.Flush();
                newStream.Close();
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                using (var stream = response.GetResponseStream())
                {
                    using (var sr = new StreamReader(stream))
                    {
                        string result = sr.ReadToEnd();

                        return result;
                    }
                }
            }
        }
    }

    public class AXCredentialsContract
    {
        public string AXApiActiveDirectoryClientAppId { get; set; }
        public string AxApiActiveDirectoryClientAppSecret { get; set; }
        public string AXApiActiveDirectoryResource { get; set; }
        public string AXApiActiveDirectoryTenant { get; set; }
        public string AXApiPassword { get; set; }
        public string AXApiUserName { get; set; }
        public string AXBaseUri { get; set; }
    }

    public static class AXConnector
    {
        public static AXCredentialsContract GetAppConfiguration()
        {
            AXCredentialsContract axCredentialsContract = new AXCredentialsContract();
          
            axCredentialsContract.AXApiActiveDirectoryClientAppId = "1a70e9c5-4825-4c34-96f3-84e8d1bb3da8";
                
            axCredentialsContract.AxApiActiveDirectoryClientAppSecret = "NNk8Q~4KpXLWo5BkVHZxPFe4qZJM4yCLpUzNta7I";
               
            axCredentialsContract.AXApiActiveDirectoryResource = "https://usnconeboxax1aos.cloud.onebox.dynamics.com";
               
            axCredentialsContract.AXApiActiveDirectoryTenant = "https://login.microsoftonline.com/032703fb-9855-4cd0-8cf5-c3e8a0fe7889";
                
            return axCredentialsContract;
        }
    }
}
