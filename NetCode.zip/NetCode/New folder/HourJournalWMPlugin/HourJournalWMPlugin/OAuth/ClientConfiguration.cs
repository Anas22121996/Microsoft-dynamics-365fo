﻿using System;
using System.Collections.Generic;

namespace HourJournalIntegration
{
    public class ClientConfiguration
    {
        public string UriString { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ActiveDirectoryResource { get; set; }
        public string ActiveDirectoryTenant { get; set; }
        public string ActiveDirectoryClientAppId { get; set; }
        public string ActiveDirectoryClientAppSecret { get; set; }
        public string ServicePath { get; set; }
    }
}