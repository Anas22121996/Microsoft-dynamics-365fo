﻿using System;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;

namespace HourJournalIntegration
{
    class OAuthHelper
    {
        /// <summary>
        /// Retrieves an authentication header from the service.
        /// </summary>
        /// <returns>The authentication header for the Web API call.</returns>
        public static string GetAuthenticationToken()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://login.microsoftonline.com/032703fb-9855-4cd0-8cf5-c3e8a0fe7889/oauth2/token");

            request.ContentType = "application/x-www-form-urlencoded";
            request.Method = "POST";

            string data = string.Format(@"grant_type=client_credentials&client_id={0}&client_secret={1}&resource={2}",
                             "1a70e9c5-4825-4c34-96f3-84e8d1bb3da8",
                             "NNk8Q~4KpXLWo5BkVHZxPFe4qZJM4yCLpUzNta7I",
                             "https://usnconeboxax1aos.cloud.onebox.dynamics.com");

            request.ContentLength = data.Length;
            byte[] bytes = Encoding.ASCII.GetBytes(data);

            using (Stream reqStream = request.GetRequestStream())
            {
                reqStream.Write(bytes, 0, data.Length);
                reqStream.Flush();
                reqStream.Close();
            }

            AzureAccessToken token = new AzureAccessToken();

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                using (var stream = response.GetResponseStream())
                {
                    DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(AzureAccessToken));
                    token = (AzureAccessToken)serializer.ReadObject(stream);
                }

            }

            return string.Format("bearer {0}", token.access_token);
        }

    }
}
